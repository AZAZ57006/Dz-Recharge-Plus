# OneClick v3 Live Plan Catalog — Grouped by Operator

Source: GET https://api.oneclickdz.com/v3/mobile/plans
API response timestamp: 2026-07-08T07:01:05.166Z

Raw values as returned by OneClick (pipe characters in names are escaped only for Markdown table rendering; values are otherwise untouched). No renaming or summarizing applied.

## Mobilis

### Mobilis — dynamicPlans (3)

| code | name | amount | operator | isEnabled |
|---|---|---|---|---|
| FACTURE_MOBILIS | 📋 FACTURE \| فاتورة | 100-3999 | Mobilis | True |
| INTERNATIONAL_Mobilis | 🌎 INTERNATIONAL \| دولي | 200-4000 | Mobilis | True |
| PREPAID_MOBILIS | 📱 PREPAID \| عادي | 40-3999 | Mobilis | True |

### Mobilis — fixedPlans (16)

| code | name | amount | operator | isEnabled |
|---|---|---|---|---|
| GETMENU_Mobilis | إظهار كافة العروض  | 0 | Mobilis | True |
| TALK500_MOBILIS | 📱 AUTO \| TALK 500 | 500 | Mobilis | True |
| NET1000_MOBILIS | 🌐 AUTO \| NET 1000 | 1000 | Mobilis | True |
| TALK1500_MOBILIS | 📱 AUTO \| TALK 1500 | 1500 | Mobilis | True |
| MIX1800_MOBILIS | 📱 AUTO \| Revolution 1800 | 1800 | Mobilis | True |
| MIX1500_MOBILIS | 📱🌐 AUTO \| MIX 1500 | 1500 | Mobilis | True |
| TALK2000_MOBILIS | 📱 AUTO \| TALK 2000 | 2000 | Mobilis | True |
| MIX2500_MOBILIS | 📱 AUTO \| Revolution 2500 | 2500 | Mobilis | True |
| MIX500_MOBILIS | 📱🌐 AUTO \| MIX 500 | 500 | Mobilis | True |
| NET500_MOBILIS | 🌐 AUTO \| NET 500 | 500 | Mobilis | True |
| TALK1000_MOBILIS | 📱 AUTO \| TALK 1000 | 1000 | Mobilis | True |
| MIX1000_MOBILIS | 📱🌐 AUTO \| MIX 1000 | 1000 | Mobilis | True |
| NET1500_MOBILIS | 🌐 AUTO \| NET 1500 | 1500 | Mobilis | True |
| MIX2000_MOBILIS | 📱🌐 AUTO \| MIX 2000 | 2000 | Mobilis | True |
| NET2000_MOBILIS | 🌐 AUTO \| NET 2000 | 2000 | Mobilis | True |
| MIX1200_MOBILIS | 📱 AUTO \| Revolution 1200 | 1200 | Mobilis | True |

## Djezzy

### Djezzy — dynamicPlans (2)

| code | name | amount | operator | isEnabled |
|---|---|---|---|---|
| PREPAID_DJEZZY | 📱 PREPAID \| عادي | 100-10000 | Djezzy | True |
| FACTURE_DJEZZY | 📋 FACTURE \| فاتورة | 100-10000 | Djezzy | True |

### Djezzy — fixedPlans (14)

| code | name | amount | operator | isEnabled |
|---|---|---|---|---|
| GETMENU_Djezzy | إظهار كافة العروض  | 0 | Djezzy | True |
| MIX50_DJEZZY | 📱🌐 Auto \| MIX 50 | 50 | Djezzy | True |
| MIX100_DJEZZY | 📱🌐 Auto \| MIX 100 | 100 | Djezzy | True |
| MIX200_DJEZZY | 📱🌐 ZID \| MIX 200 | 200 | Djezzy | True |
| MIX300_DJEZZY | 📱🌐 iZZY \| MIX 300 | 300 | Djezzy | True |
| MIX400_DJEZZY | 📱🌐 AUTO \| MIX 400 | 400 | Djezzy | True |
| MIX500_DJEZZY | 📱🌐 AUTO \| MIX 500 | 500 | Djezzy | True |
| MIX800_DJEZZY | 📱🌐 ZID \| MIX 800 | 800 | Djezzy | True |
| MIX1000_DJEZZY | 📱🌐 AUTO \| MIX 1000 | 1000 | Djezzy | True |
| MIX1200_DJEZZY | 📱🌐 AUTO \| MIX 1200 | 1200 | Djezzy | True |
| MIX1500_DJEZZY | 📱🌐 AUTO \| MIX 1500 | 1500 | Djezzy | True |
| MIX2000_DJEZZY | 📱🌐 AUTO \| MIX 2000 | 2000 | Djezzy | True |
| MIX2500_DJEZZY | 📱🌐 AUTO \| MIX 2500 | 2500 | Djezzy | True |
| MIX4000_DJEZZY | 📱🌐 Internet 150 Go \| MIX 4000 | 4000 | Djezzy | True |

## Ooredoo

### Ooredoo — dynamicPlans (2)

| code | name | amount | operator | isEnabled |
|---|---|---|---|---|
| PREPAID_OOREDOO | 📱 PREPAID \| عادي | 100-50000 | Ooredoo | True |
| ENTERPRISE_OOREDOO | 📋 ENTERPRISE \| فاتورة | 100-50000 | Ooredoo | True |

### Ooredoo — fixedPlans (23)

| code | name | amount | operator | isEnabled |
|---|---|---|---|---|
| GETMENU_Ooredoo | إظهار كافة العروض  | 0 | Ooredoo | True |
| MIX50_OOREDOO | 📱🌐 Auto \| MIX 50 | 50 | Ooredoo | True |
| TALK50_OOREDOO | 📱 60mn Ooredoo \| AUTO 50 | 50 | Ooredoo | True |
| MIX100_OOREDOO | 📱🌐 Auto \| MIX 100 | 100 | Ooredoo | True |
| NET100_OOREDOO | 🌐 Forfait \| NET 100 | 100 | Ooredoo | True |
| TALKOOREDOO100_OOREDOO | 📱 Ooredoo \| TALK 100 | 100 | Ooredoo | True |
| TALK100_OOREDOO | 📱 Tous \| TALK 100 | 100 | Ooredoo | True |
| TALK150_OOREDOO | 📱 ILLIMITE + 15mn \| TALK 100 | 150 | Ooredoo | True |
| MIX200_OOREDOO | 📱🌐 Auto \| MIX 200 | 200 | Ooredoo | True |
| NET300_OOREDOO | 🌐 Forfait \| NET 300 | 300 | Ooredoo | True |
| MIX500_OOREDOO | 📱🌐 AUTO \| MIX 500 | 500 | Ooredoo | True |
| NET500_OOREDOO | 🌐 AUTO \| NET 500 | 500 | Ooredoo | True |
| MIX1000_OOREDOO | 📱🌐 AUTO \| MIX 1000 | 1000 | Ooredoo | True |
| NET1000_OOREDOO | 🌐 15+5 Youtube \| NET 1000 | 1000 | Ooredoo | True |
| TALK1000_OOREDOO | 📱🌐 HADRA \| TALK 1000 | 1000 | Ooredoo | True |
| MIX1200_OOREDOO | 📱🌐 Dima 1200 \| MIX 1200 | 1200 | Ooredoo | True |
| MIX1500_OOREDOO | 📱🌐 AUTO \| MIX 1500 | 1500 | Ooredoo | True |
| NET1500_OOREDOO | 🌐 40Go+ ILLIMITE Youtube \| NET 1500 | 1500 | Ooredoo | True |
| MIX2000_OOREDOO | 📱🌐 AUTO \| MIX 2000 | 2000 | Ooredoo | True |
| NET2000_OOREDOO | 📱🌐 MAXY INTERNET \| NET 2000 | 2000 | Ooredoo | True |
| MIX2500_OOREDOO | 📱🌐 AUTO \| MIX 2500 | 2500 | Ooredoo | True |
| MIX3500_OOREDOO | 📱🌐 AUTO \| MIX 3500 | 3500 | Ooredoo | True |
| MIX5000_OOREDOO | 📱🌐 Sahla box 5000 \| MIX 5000 | 5000 | Ooredoo | True |

## Other operator variants present in the account (wholesale, etc.)

### GDjezzy

| code | name | amount | operator | isEnabled |
|---|---|---|---|---|
| GROS_DJEZZY | 📱 GROS DJEZZY \| جملة | 5000-300000 | GDjezzy | True |

### GMobilis

| code | name | amount | operator | isEnabled |
|---|---|---|---|---|
| GROS_MOBILIS | 📱 GROS MOBILIS \| جملة | 5000-300000 | GMobilis | True |

### GOoredoo

| code | name | amount | operator | isEnabled |
|---|---|---|---|---|
| GROS_OOREDOO | 📱 GROS OOREDOO \| جملة | 10000-300000 | GOoredoo | True |

