# OneClick v3 Live Plan Catalog Export

Fetched from GET https://api.oneclickdz.com/v3/mobile/plans
API response timestamp: 2026-07-08T07:01:05.166Z
success: True

This is a raw, unmodified export of the live catalog. No renaming or mapping applied.

## dynamicPlans (10)

| code | name | operator | cost | min_amount | max_amount | isEnabled |
|---|---|---|---|---|---|---|
| PREPAID_DJEZZY | 📱 PREPAID | عادي | Djezzy | 0.995 | 100 | 10000 | True |
| FACTURE_DJEZZY | 📋 FACTURE | فاتورة | Djezzy | 0.995 | 100 | 10000 | True |
| GROS_MOBILIS | 📱 GROS MOBILIS | جملة | GMobilis |  | 5000 | 300000 | True |
| GROS_DJEZZY | 📱 GROS DJEZZY | جملة | GDjezzy |  | 5000 | 300000 | True |
| GROS_OOREDOO | 📱 GROS OOREDOO | جملة | GOoredoo |  | 10000 | 300000 | True |
| PREPAID_OOREDOO | 📱 PREPAID | عادي | Ooredoo | 0.995 | 100 | 50000 | True |
| ENTERPRISE_OOREDOO | 📋 ENTERPRISE | فاتورة | Ooredoo | 0.995 | 100 | 50000 | True |
| FACTURE_MOBILIS | 📋 FACTURE | فاتورة | Mobilis | 0.98 | 100 | 3999 | True |
| INTERNATIONAL_Mobilis | 🌎 INTERNATIONAL | دولي | Mobilis | 0.98 | 200 | 4000 | True |
| PREPAID_MOBILIS | 📱 PREPAID | عادي | Mobilis | 0.98 | 40 | 3999 | True |

## fixedPlans (53)

| code | name | operator | cost | amount | isEnabled |
|---|---|---|---|---|---|
| GETMENU_Djezzy | إظهار كافة العروض  | Djezzy | 0.995 | 0 | True |
| MIX50_DJEZZY | 📱🌐 Auto | MIX 50 | Djezzy | 0.995 | 50 | True |
| MIX100_DJEZZY | 📱🌐 Auto | MIX 100 | Djezzy | 0.995 | 100 | True |
| MIX200_DJEZZY | 📱🌐 ZID | MIX 200 | Djezzy | 0.995 | 200 | True |
| MIX300_DJEZZY | 📱🌐 iZZY | MIX 300 | Djezzy | 0.995 | 300 | True |
| MIX400_DJEZZY | 📱🌐 AUTO | MIX 400 | Djezzy | 0.995 | 400 | True |
| MIX500_DJEZZY | 📱🌐 AUTO | MIX 500 | Djezzy | 0.995 | 500 | True |
| MIX800_DJEZZY | 📱🌐 ZID | MIX 800 | Djezzy | 0.995 | 800 | True |
| MIX1000_DJEZZY | 📱🌐 AUTO | MIX 1000 | Djezzy | 0.995 | 1000 | True |
| MIX1200_DJEZZY | 📱🌐 AUTO | MIX 1200 | Djezzy | 0.995 | 1200 | True |
| MIX1500_DJEZZY | 📱🌐 AUTO | MIX 1500 | Djezzy | 0.995 | 1500 | True |
| MIX2000_DJEZZY | 📱🌐 AUTO | MIX 2000 | Djezzy | 0.995 | 2000 | True |
| MIX2500_DJEZZY | 📱🌐 AUTO | MIX 2500 | Djezzy | 0.995 | 2500 | True |
| MIX4000_DJEZZY | 📱🌐 Internet 150 Go | MIX 4000 | Djezzy | 0.995 | 4000 | True |
| GETMENU_Ooredoo | إظهار كافة العروض  | Ooredoo | 0.995 | 0 | True |
| MIX50_OOREDOO | 📱🌐 Auto | MIX 50 | Ooredoo | 0.995 | 50 | True |
| TALK50_OOREDOO | 📱 60mn Ooredoo | AUTO 50 | Ooredoo | 0.995 | 50 | True |
| MIX100_OOREDOO | 📱🌐 Auto | MIX 100 | Ooredoo | 0.995 | 100 | True |
| NET100_OOREDOO | 🌐 Forfait | NET 100 | Ooredoo | 0.995 | 100 | True |
| TALKOOREDOO100_OOREDOO | 📱 Ooredoo | TALK 100 | Ooredoo | 0.995 | 100 | True |
| TALK100_OOREDOO | 📱 Tous | TALK 100 | Ooredoo | 0.995 | 100 | True |
| TALK150_OOREDOO | 📱 ILLIMITE + 15mn | TALK 100 | Ooredoo | 0.995 | 150 | True |
| MIX200_OOREDOO | 📱🌐 Auto | MIX 200 | Ooredoo | 0.995 | 200 | True |
| NET300_OOREDOO | 🌐 Forfait | NET 300 | Ooredoo | 0.995 | 300 | True |
| MIX500_OOREDOO | 📱🌐 AUTO | MIX 500 | Ooredoo | 0.995 | 500 | True |
| NET500_OOREDOO | 🌐 AUTO | NET 500 | Ooredoo | 0.995 | 500 | True |
| MIX1000_OOREDOO | 📱🌐 AUTO | MIX 1000 | Ooredoo | 0.995 | 1000 | True |
| NET1000_OOREDOO | 🌐 15+5 Youtube | NET 1000 | Ooredoo | 0.995 | 1000 | True |
| TALK1000_OOREDOO | 📱🌐 HADRA | TALK 1000 | Ooredoo | 0.995 | 1000 | True |
| MIX1200_OOREDOO | 📱🌐 Dima 1200 | MIX 1200 | Ooredoo | 0.995 | 1200 | True |
| MIX1500_OOREDOO | 📱🌐 AUTO | MIX 1500 | Ooredoo | 0.995 | 1500 | True |
| NET1500_OOREDOO | 🌐 40Go+ ILLIMITE Youtube | NET 1500 | Ooredoo | 0.995 | 1500 | True |
| MIX2000_OOREDOO | 📱🌐 AUTO | MIX 2000 | Ooredoo | 0.995 | 2000 | True |
| NET2000_OOREDOO | 📱🌐 MAXY INTERNET | NET 2000 | Ooredoo | 0.995 | 2000 | True |
| MIX2500_OOREDOO | 📱🌐 AUTO | MIX 2500 | Ooredoo | 0.995 | 2500 | True |
| MIX3500_OOREDOO | 📱🌐 AUTO | MIX 3500 | Ooredoo | 0.995 | 3500 | True |
| MIX5000_OOREDOO | 📱🌐 Sahla box 5000 | MIX 5000 | Ooredoo | 0.995 | 5000 | True |
| GETMENU_Mobilis | إظهار كافة العروض  | Mobilis | 0.98 | 0 | True |
| TALK500_MOBILIS | 📱 AUTO | TALK 500 | Mobilis | 0.98 | 500 | True |
| NET1000_MOBILIS | 🌐 AUTO | NET 1000 | Mobilis | 0.98 | 1000 | True |
| TALK1500_MOBILIS | 📱 AUTO | TALK 1500 | Mobilis | 0.98 | 1500 | True |
| MIX1800_MOBILIS | 📱 AUTO | Revolution 1800 | Mobilis | 0.98 | 1800 | True |
| MIX1500_MOBILIS | 📱🌐 AUTO | MIX 1500 | Mobilis | 0.98 | 1500 | True |
| TALK2000_MOBILIS | 📱 AUTO | TALK 2000 | Mobilis | 0.98 | 2000 | True |
| MIX2500_MOBILIS | 📱 AUTO | Revolution 2500 | Mobilis | 0.98 | 2500 | True |
| MIX500_MOBILIS | 📱🌐 AUTO | MIX 500 | Mobilis | 0.98 | 500 | True |
| NET500_MOBILIS | 🌐 AUTO | NET 500 | Mobilis | 0.98 | 500 | True |
| TALK1000_MOBILIS | 📱 AUTO | TALK 1000 | Mobilis | 0.98 | 1000 | True |
| MIX1000_MOBILIS | 📱🌐 AUTO | MIX 1000 | Mobilis | 0.98 | 1000 | True |
| NET1500_MOBILIS | 🌐 AUTO | NET 1500 | Mobilis | 0.98 | 1500 | True |
| MIX2000_MOBILIS | 📱🌐 AUTO | MIX 2000 | Mobilis | 0.98 | 2000 | True |
| NET2000_MOBILIS | 🌐 AUTO | NET 2000 | Mobilis | 0.98 | 2000 | True |
| MIX1200_MOBILIS | 📱 AUTO | Revolution 1200 | Mobilis | 0.98 | 1200 | True |
